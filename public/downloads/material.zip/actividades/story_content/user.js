function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5bjN9378zqW":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

